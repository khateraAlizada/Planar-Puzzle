export const layout = {
    canvas : {
        height: "500",
        width: "500",
    },

    Appmain : {
        backgroundColor: "#320453",
        height: "100vh",
        width: "100vw",
    },
    text: { 
        position: "absolute",
        left:500,
        top:50,
        color:"yellow",
        backgroundColor: "#320453",
        width:1500,
      },

    buttons: { 
        position: "absolute",
        left: 1500,
        top:90
    }
}